drcom
=====

Uestc沙河校区教育网拨号器

Windows客户端  http://pan.baidu.com/s/1dD3WAWx

Mac客户端 http://pan.baidu.com/s/1gdsxnyz

拨号器与学校官方提供的拨号方式不同，这个使用的是web方式登录，与之前有人提供的chrome插件类似，此软件使用node-webkit打包成了各个平台的桌面软件。

使用web登录方式不需要再一直开着拨号器上网，使用全局vpn不再掉线，想使用路由器的同学特别推荐此种登录方式，登录一次后在路由器上设置为静态ip，一次拨号，终生幸福！

当你冒然拔掉路由器wan口网线时需要这个电话！信息中心电话：83203691，告诉他你的号被人登了就OK. 

---

[路由器wifi设置方法](https://keith3.github.io/drcom.html)
